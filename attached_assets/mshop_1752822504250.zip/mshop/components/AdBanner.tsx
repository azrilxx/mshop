import { Advertisement } from '@/lib/db'
import Link from 'next/link'

interface AdBannerProps {
  ad: Advertisement
}

export default function AdBanner({ ad }: AdBannerProps) {
  return (
    <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
      <div className="aspect-w-16 aspect-h-9">
        <img
          src={ad.imageUrl}
          alt={ad.title}
          className="w-full h-32 object-cover"
        />
      </div>
      
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold text-gray-900">{ad.title}</h3>
          <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
            Featured
          </span>
        </div>
        
        <p className="text-xs text-gray-600 mb-3 line-clamp-2">{ad.description}</p>
        
        <Link 
          href={`/products/${ad.productId}`}
          className="inline-flex items-center text-xs font-medium text-blue-600 hover:text-blue-800"
        >
          View Product
          <svg className="ml-1 w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </Link>
      </div>
    </div>
  )
}